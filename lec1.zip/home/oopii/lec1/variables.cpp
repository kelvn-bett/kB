#include <iostream>
using namespace std;
int main()
{
    int x;
    x = 4 + 2;
    cout << x / 3 << ’’<<x * 2;
    return 0;
}
