#include <iostream>

using namespace std;

int main()
{

    int x = 0;
    while (x < 10) {
        cout << x << "\n";
        x = x + 1;
    }

    return 0;

}
