#include <iostream>

using namespace std;

int main()
{
    int N;
    cin >> N;
    while (N-- > 0) {
        cout << "Hello, World!\n";
    }
    return 0;
}
