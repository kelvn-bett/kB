#include <iostream>

using namespace std;

int main()
{
    const char *str = "Hello, World!";
    cout << str << "\n";
    return 0;
}
